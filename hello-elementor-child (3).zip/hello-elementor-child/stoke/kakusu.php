

<div id="wrapper" class="cf">
<div id="content">
<h1 class="ttl_main">漢字を画数から検索</h1>
<aside><div class="ads_wrapin link_pc">
<script async src="../../pagead2.googlesyndication.com/pagead/js/fb9f7.txt?client=ca-pub-3664445671894613"
     crossorigin="anonymous"></script>
<!-- 漢字辞典レスポンシブ１ -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3664445671894613"
     data-ad-slot="5169795341"
     data-ad-format="horizontal"
     data-full-width-responsive="true"></ins>

</div></aside>
<div class="data_cont">
<p>漢字を画数から検索することができます。</p>
<aside><div class="ads_wraptop2 link_sp">

<!-- 漢字辞典レスポンシブカテゴリ上SP -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3664445671894613"
     data-ad-slot="8563864342"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>

</div></aside>
   

<div class="kakusu_area">
<ul>
<li><a href="kakusu01">1<span class="small">画</span></a></li>
<li><a href="kakusu02">2<span class="small">画</span></a></li>
<li><a href="kakusu03">3<span class="small">画</span></a></li>
<li><a href="kakusu04">4<span class="small">画</span></a></li>
<li><a href="kakusu05">5<span class="small">画</span></a></li>
<li><a href="kakusu06">6<span class="small">画</span></a></li>
<li><a href="kakusu07">7<span class="small">画</span></a></li>
<li><a href="kakusu08">8<span class="small">画</span></a></li>
<li><a href="kakusu09">9<span class="small">画</span></a></li>
<li><a href="kakusu10">10<span class="small">画</span></a></li>
<li><a href="kakusu11">11<span class="small">画</span></a></li>
<li><a href="kakusu12">12<span class="small">画</span></a></li>
<li><a href="kakusu13">13<span class="small">画</span></a></li>
<li><a href="kakusu14">14<span class="small">画</span></a></li>
<li><a href="kakusu15">15<span class="small">画</span></a></li>
<li><a href="kakusu16">16<span class="small">画</span></a></li>
<li><a href="kakusu17">17<span class="small">画</span></a></li>
<li><a href="kakusu18">18<span class="small">画</span></a></li>
<li><a href="kakusu19">19<span class="small">画</span></a></li>
<li><a href="kakusu20">20<span class="small">画</span></a></li>
<li><a href="kakusu21">21<span class="small">画</span></a></li>
<li><a href="kakusu22">22<span class="small">画</span></a></li>
<li><a href="kakusu23">23<span class="small">画</span></a></li>
<li><a href="kakusu24">24<span class="small">画</span></a></li>
<li><a href="kakusu25">25<span class="small">画</span></a></li>
<li><a href="kakusu26">26<span class="small">画</span></a></li>
<li><a href="kakusu27">27<span class="small">画</span></a></li>
<li><a href="kakusu28">28<span class="small">画</span></a></li>
<li><a href="kakusu29">29<span class="small">画</span></a></li>
<li><a href="kakusu30">30<span class="small">画</span></a></li>
<li><a href="kakusu31">31<span class="small">画</span></a></li>
<li><a href="kakusu32">32<span class="small">画</span></a></li>
<li><a href="kakusu33">33<span class="small">画</span></a></li>
<li><a href="kakusu34">34<span class="small">画</span></a></li>
<li><a href="kakusu35">35<span class="small">画</span></a></li>
<li><a href="kakusu36">36<span class="small">画</span></a></li>
<li><a href="kakusu39">39<span class="small">画</span></a></li>
<li><a href="kakusu44">44<span class="small">画</span></a></li>
<li><a href="kakusu48">48<span class="small">画</span></a></li>
<li><a href="kakusu52">52<span class="small">画</span></a></li>
</ul>
</div>
</div><!--data_cont-->
<aside><div class="ads_wrapin link_pc">

<!-- レスポンシブ個別 -->


</div></aside>
</div><!--content-->
<aside>
<div id="sidebar" data-nosnippet> 

<div class="ads_wrap side_pc">
<style>
	.ads_responsive_2 { display: none; }
	@media(min-width: 1095px) { .ads_responsive_2 { width: 300px; height: 600px; } }
</style>

<!-- 漢字辞典レスポンシブ２ -->
<ins class="adsbygoogle ads_responsive_2"
		 style="display:inline-block"
		 data-ad-client="ca-pub-3664445671894613"
		 data-ad-slot="6642164275"></ins>
<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div><div class="side_bnr link_pc">
<a href="">
</div>
<div class="side_bnr link_sp">
<a href="">
</div><div class="side_ranking">
<script>
$(function () {
  var sel_index = localStorage.getItem("sel_Elem2");
  if(sel_index == null){sel_index = 0;}
  $('.ChangeElem_Btn2').eq(sel_index).addClass('is-active');
  $('.ChangeElem_Panel2').eq(sel_index).show();
  $('.ChangeElem_Btn2').each(function () {
    $(this).on('click', function () {
	  var parent = $(this).parents(".side_box");
      var index = $(parent).find('.ChangeElem_Btn2').index(this);
      $(parent).find('.ChangeElem_Btn2').removeClass('is-active');
      $(this).addClass('is-active');
      $(parent).find('.ChangeElem_Panel2').hide();
      $(parent).find('.ChangeElem_Panel2').eq(index).show();
	  localStorage.setItem('sel_Elem2', index);
    });
  });
});
</script>
  
<div class="side_box">
<p class="ttl_normal_s"><span class="rank_update">11/17更新</span></p> 
<ul class="ChangeElem_Btn_Content2 rank_menu">
<li class="ChangeElem_Btn2">デイリー</li>
<li class="ChangeElem_Btn2">週間</li>
<li class="ChangeElem_Btn2">月間</li>
</ul>
<div class="ChangeElem_Panel2">
<ul class="side_rank sr_01">
<li><a href="kanji/059" title="漢字「中」のページ"><span class="rank">1</span><span class="jp">中</span></a></li><li><a href="kanji/190" title="漢字「長」のページ"><span class="rank">6</span><span class="jp">長</span></a></li><li><a href="kanji/136" title="漢字「国」のページ"><span class="rank">2</span><span class="jp">国</span></a></li><li><a href="kanji/252" title="漢字「駅」のページ"><span class="rank">7</span><span class="jp">駅</span></a></li><li><a href="kanji/071" title="漢字「本」のページ"><span class="rank">3</span><span class="jp">本</span></a></li><li><a href="671" title="漢字「寄」のページ"><span class="rank">8</span><span class="jp">寄</span></a></li><li><a href="kanji/086" title="漢字「家」のページ"><span class="rank">4</span><span class="jp">家</span></a></li><li><a href="kanji/114" title="漢字「兄」のページ"><span class="rank">9</span><span class="jp">兄</span></a></li><li><a href="775" title="漢字「提」のページ"><span class="rank">5</span><span class="jp">提</span></a></li><li><a href="12934" title="漢字「殺」のページ"><span class="rank">10</span><span class="jp">殺</span></a></li></ul>
</div><!--ChangeElem_Panel2-->
<div class="ChangeElem_Panel2">
<ul class="side_rank">
<li><a href="kanji/059" title="漢字「中」のページ"><span class="rank">1</span><span class="jp">中</span></a></li><li><a href="kanji/163" title="漢字「新」のページ"><span class="rank">6</span><span class="jp">新</span></a></li><li><a href="kanji/423" title="漢字「有」のページ"><span class="rank">2</span><span class="jp">有</span></a></li><li><a href="602" title="漢字「無」のページ"><span class="rank">7</span><span class="jp">無</span></a></li><li><a href="kanji/071" title="漢字「本」のページ"><span class="rank">3</span><span class="jp">本</span></a></li><li><a href="911" title="漢字「将」のページ"><span class="rank">8</span><span class="jp">将</span></a></li><li><a href="kanji/086" title="漢字「家」のページ"><span class="rank">4</span><span class="jp">家</span></a></li><li><a href="kanji/190" title="漢字「長」のページ"><span class="rank">9</span><span class="jp">長</span></a></li><li><a href="kanji/136" title="漢字「国」のページ"><span class="rank">5</span><span class="jp">国</span></a></li><li><a href="kanji/094" title="漢字「海」のページ"><span class="rank">10</span><span class="jp">海</span></a></li></ul>
</div><!--ChangeElem_Panel2-->
<div class="ChangeElem_Panel2">
<ul class="side_rank">
<li><a href="kanji/059" title="漢字「中」のページ"><span class="rank">1</span><span class="jp">中</span></a></li><li><a href="kanji/086" title="漢字「家」のページ"><span class="rank">6</span><span class="jp">家</span></a></li><li><a href="991" title="漢字「優」のページ"><span class="rank">2</span><span class="jp">優</span></a></li><li><a href="kanji/398" title="漢字「美」のページ"><span class="rank">7</span><span class="jp">美</span></a></li><li><a href="602" title="漢字「無」のページ"><span class="rank">3</span><span class="jp">無</span></a></li><li><a href="kanji/423" title="漢字「有」のページ"><span class="rank">8</span><span class="jp">有</span></a></li><li><a href="kanji/439" title="漢字「和」のページ"><span class="rank">4</span><span class="jp">和</span></a></li><li><a href="kanji/071" title="漢字「本」のページ"><span class="rank">9</span><span class="jp">本</span></a></li><li><a href="kanji/440" title="漢字「愛」のページ"><span class="rank">5</span><span class="jp">愛</span></a></li><li><a href="kanji/027" title="漢字「子」のページ"><span class="rank">10</span><span class="jp">子</span></a></li>      
</ul>
</div><!--ChangeElem_Panel2-->
</div>
</div>
<script>
$(function(){
	$('.togglemenu').click(function(){
		$(this).toggleClass("active").next().slideToggle(300);
	});
});
</script>
<div class="side_box">
<p class="ttl_main_s togglemenu">検索メニュー</p>
<div class="togglebox">
<ul class="other_site">
<li><a href="yomi">読み検索（音訓検索）</a></li>
<li><a href="kakusu">画数検索</a></li>
<li><a href="bushu">部首検索</a></li>
<li><a href="kousei/">構成検索</a></li>
<li><a href="kyu">漢検の級（習う学年）から検索</a></li>
<li><a href="searchdetail">詳細検索</a></li>
</ul>
</div><!--togglebox-->
</div><!--side_box-->
<div class="side_box">
<p class="ttl_main_s togglemenu">練習帳</p>
<div class="togglebox">
<ul class="other_site">
<li><a href="exercisebook/free.php">漢字練習帳</a></li>
<li><a href="exercisebook/free.php#kr1">カスタム練習帳</a></li>
<li><a href="exercisebook/free.php#kr2">漢検級別（学年別）練習帳</a></li>
</ul>
</div><!--togglebox-->
</div><!--side_box-->
<div class="side_box">
<p class="ttl_main_s togglemenu">漢字の種別</p>
<div class="togglebox">
<ul class="other_site">
<li><a href="joyo">常用漢字</a></li>
<li><a href="kyoiku">教育漢字</a></li>
<li><a href="jimmei">人名用漢字</a></li>
<li><a href="namae">名前に使える漢字</a></li>
<li><a href="kokuji">国字</a></li>
</ul>
</div><!--togglebox-->
</div><!--side_box-->
<div class="side_box">
<p class="ttl_main_s togglemenu">漢字の分類・漢字表記</p>
<div class="togglebox">
<ul class="other_site">
<li><a href="sakuin1">漢字の分類・漢字表記索引</a></li>
</ul>
</div><!--togglebox-->
</div><!--side_box-->
<div class="side_box">
<p class="ttl_main_s togglemenu">漢字情報</p>
<div class="togglebox">
<ul class="other_site">
<li><a href="">偏旁（偏旁冠脚）</a></li>    
<li><a href="kotoshi/">今年の漢字</a></li>
<li><a href="kotoshi/rekidai">歴代の今年の漢字</a></li>
<li><a href="osusume">おすすめの漢字辞典・漢和辞典</a></li>
</ul>
</div><!--togglebox-->
</div><!--side_box-->
</div><!--sidebar-->
</aside></div><!--wrapper-->
<div class="page_top"><a href="#"><img src="../../jitenon.jp/images/top.png" alt="ページ先頭に戻る"></a></div>
<footer>
<div class="footer_wrap" data-nosnippet>
<div class="center">
<div class="footer_bottom">
<ul class="footer_menu">
<li><a href="info">報告・お問い合わせ</a></li>
<li><a href="privacy">プライバシーポリシー</a></li>
<li><a href="info/document.php">参考文献</a></li>
<li><a href="https://jitenon.jp/">運営サイト一覧</a></li>
<li><a href="https://jitenon.co.jp/">運営会社</a></li>
</ul>
<div class="language_footer">
<div class="lan_inner">
<select name="select" onChange="location.href=value;" tabindex="0">
<option value="" selected>Language</option>
<option value="https://jitenon.com/cat/stroke_top.php">English</option>
<option value="kakusu">Japanese</option>
</select>
</div>
</div>
</div>
</div>
</div>
<p class="copyright">&copy; 2012-2023  漢字辞典オンライン</p>
</footer>
</div><!--all-->
</body>

<!-- Mirrored from kanji.jitenon.jp/cat/kakusu by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 17 Nov 2023 00:36:44 GMT -->
</html>