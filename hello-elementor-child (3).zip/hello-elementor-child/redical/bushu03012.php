<?php
/*
 * Template Name: bushu02011
 * */

get_header();

?>
  <link rel="stylesheet" type="text/css" href="<?= get_stylesheet_directory_uri(); ?>/assest/css/html5reset.css" media="screen" />
  <link rel="stylesheet" type="text/css" href="<?= get_stylesheet_directory_uri(); ?>/assest/css/styleed06.css?20231023" media="screen" />
  <link rel="stylesheet" type="text/css" href="<?= get_stylesheet_directory_uri(); ?>/assest/css/style_kanjied06.css?20231023" media="screen" />
  <title>漢字を読みから検索（音訓検索）</title>
  <script src="<?= get_stylesheet_directory_uri(); ?>/assest/js/jquery-3.4.1.min.js"></script>
  <script src="<?= get_stylesheet_directory_uri(); ?>/assest/js/jquery.cookie.js"></script>
  <script type="text/javascript" src="<?= get_stylesheet_directory_uri(); ?>/assest/js/main/main0598.js?20231008"></script>
  <script type="text/javascript" src="<?= get_stylesheet_directory_uri(); ?>/assest/js/kanji/main0598.js?20231008"></script>
  <div id="all">
  <header>
  <div class="nosnippet" data-nosnippet>
  
  <div class="header_search" data-nosnippet>
  <div class="search_inner">
  <form id="head_form" class="search_form" name="head_form" accept-charset="utf-8" method="post">
  <span id="select_search" class="select_search">すべて</span>
  <input type="hidden" id="slide2">
  <input type="hidden" id="head_how" class="how" value="すべて">
  <input type="text" id="head_value" name="value" placeholder="例）にんべん 車車車 5画" class="value input_search" value="">
  <input type="submit" id="head_submit" value="" class="search_btn">
  </form>
  <div id="target2" class="search_target search_other">
  <ul id="select01" class="cf">
  <li><a href="#" class="sel1 head-active" id="sel11">abc</a></li>
  <li><a href="#" class="sel1" id="sel12">漢字</a></li>
  <li><a href="#" class="sel1" id="sel15">意味</a></li>
  <li><a href="#" class="sel1" id="sel13">部首</a></li>
  <li><a href="#" class="sel1" id="sel14">構成</a></li>
  </ul>
  <ul id="select02" class="cf">
  <li><a href="#" class="sel2 head-active" id="sel21">を含む</a></li>
  <li><a href="#" class="sel2" id="sel22">から始まる</a></li>
  <li><a href="#" class="sel2" id="sel23">で終わる</a></li>
  <li><a href="#" class="sel2" id="sel24">と一致する</a></li>
  </ul>
  <div class="detail_search">
  <a href="searchdetail">さらに詳しい条件で検索<span>▶</span></a>
  </div>
  </div>
  </div>
  </div>
  <div class="contents_bnr link_sp">
  
  </div></div>
  </header>
          <div id="wrapper" class="cf">
               <div id="content">
                    <h1 class="ttl_main">部首：土部（つち・つちへん・どへん）の漢字</h1>

                    <div class="bushu_about">
                         <div class="bushu_about_box">
                              <h2>土部とは？</h2>
                              <p>土部（どぶ）は、<strong><span
                                             class="marker">土、地面、土地の状態など、土に関係する字</span>が多く属します。</strong>「土」は「つち」、偏になった形を「つちへん」「どへん」と呼びます。
                              </p>
                         </div>
                    </div>
                    <div class="parts_data">
                         <div class="search_narrowdown">
                              <script>
                                   (function () {
                                        var html = document.getElementsByTagName('html') || [];
                                        html[0].classList.add('enable-javascript');
                                   })();
                              </script>
                              <div class="narrowdown_select">
                                   <select name="select" onChange="location.href=value;" class="select1">
                                        <option value="bushu08003">靑 青（あお・あおへん）</option>
                                        <option value="bushu07004">赤（あか・あかへん）</option>
                                        <option value="bushu04010">欠（あくび）</option>
                                        <option value="bushu11007">麻（あさ・あさかんむり）</option>
                                        <option value="bushu07005">足（あし・あしへん）</option>
                                        <option value="bushu05002">穴（あな・あなかんむり）</option>
                                        <option value="bushu05019">甘（あまい）</option>
                                        <option value="bushu08001">雨（あまかんむり）</option>
                                        <option value="bushu06018">网 罒 㓁（あみがしら・あみめ）</option>
                                        <option value="bushu08001">雨（あめ・あめかんむり）</option>
                                        <option value="bushu08007">非（あらず）</option>
                                        <option value="bushu05003">生（いきる）</option>
                                        <option value="bushu05004">石（いし・いしへん）</option>
                                        <option value="bushu06023">至（いたる・いたるへん）</option>
                                        <option value="bushu01001">一（いち）</option>
                                        <option value="bushu03013">干（いちじゅう）</option>
                                        <option value="bushu04022">歹 歺（いちたへん）</option>
                                        <option value="bushu09002">頁（いちのかい）</option>
                                        <option value="bushu06002">糸（いと）</option>
                                        <option value="bushu03033">幺（いとがしら）</option>
                                        <option value="bushu06002">糸（いとへん）</option>
                                        <option value="bushu04003">犬 犭（いぬ）</option>
                                        <option value="bushu07016">豕（いのこ）</option>
                                        <option value="bushu03035">彑 彐（いのこがしら）</option>
                                        <option value="bushu07016">豕（いのこへん）</option>
                                        <option value="bushu02007">入（いりがしら・いりやね・いる）</option>
                                        <option value="bushu06010">色（いろ）</option>
                                        <option value="bushu04014">曰（いわく）</option>
                                        <option value="bushu03028">廴（いんにょう）</option>
                                        <option value="bushu11001">魚（うお・うおへん）</option>
                                        <option value="bushu03016">宀（うかんむり）</option>
                                        <option value="bushu02005">凵（うけばこ）</option>
                                        <option value="bushu04011">牛 牜（うし）</option>
                                        <option value="bushu06019">艮（うしとら）</option>
                                        <option value="bushu04011">牛 牜（うしへん）</option>
                                        <option value="bushu04024">氏（うじ）</option>
                                        <option value="bushu06021">臼（うす）</option>
                                        <option value="bushu10002">馬（うま・うまへん）</option>
                                        <option value="bushu05003">生（うまれる）</option>
                                        <option value="bushu02022">卜（うらない）</option>
                                        <option value="bushu06028">瓜（うり）</option>
                                        <option value="bushu03004">工（え）</option>
                                        <option value="bushu04027">支（えだにょう）</option>
                                        <option value="bushu02001">冂（えんがまえ）</option>
                                        <option value="bushu03028">廴（えんにょう）</option>
                                        <option value="bushu06007">老 耂（おい・おいかんむり・おいがしら）</option>
                                        <option value="bushu03032">尢 尣（おうにょう）</option>
                                        <option value="bushu05001">玉 王 ⺩（おうへん）</option>
                                        <option value="bushu06011">襾 西 覀（おおいかんむり）</option>
                                        <option value="bushu09002">頁（おおがい）</option>
                                        <option value="bushu03027">邑 阝（おおざと）</option>
                                        <option value="bushu03024">阜 阝（おか）</option>
                                        <option value="bushu01002">乙 乚（おつ・おつにょう）</option>
                                        <option value="bushu09001">音（おと・おとへん）</option>
                                        <option value="bushu10004">鬼（おに）</option>
                                        <option value="bushu04015">斤（おの・おのづくり）</option>
                                        <option value="bushu03031">己 巳 已（おのれ）</option>
                                        <option value="bushu09006">面（おもて）</option>
                                        <option value="bushu03007">女（おんな・おんなへん）</option>
                                        <option value="bushu09009">香（か）</option>
                                        <option value="bushu07001">貝（かい・かいへん）</option>
                                        <option value="bushu13004">黽（かえるべんあし）</option>
                                        <option value="bushu09009">香（かおり）</option>
                                        <option value="bushu01005">亅（かぎ）</option>
                                        <option value="bushu07006">角（かく）</option>
                                        <option value="bushu02016">匸（かくしがまえ）</option>
                                        <option value="bushu09008">革（かくのかわ）</option>
                                        <option value="bushu04010">欠（かける）</option>
                                        <option value="bushu02021">几（かざがまえ）</option>
                                        <option value="bushu09005">風（かぜ）</option>
                                        <option value="bushu02021">几（かぜかんむり・かぜがまえ）</option>
                                        <option value="bushu04028">片（かた）</option>
                                        <option value="bushu02012">刀 刂（かたな）</option>
                                        <option value="bushu04020">方（かたへん）</option>
                                        <option value="bushu04028">片（かたへん）</option>
                                        <option value="bushu08004">門（かどがまえ）</option>
                                        <option value="bushu10009">鬲（かなえ）</option>
                                        <option value="bushu13003">鼎（かなえ）</option>
                                        <option value="bushu06011">襾 西 覀（かなめのかしら）</option>
                                        <option value="bushu08002">金 釒（かね・かねへん）</option>
                                        <option value="bushu04025">戈（かのほこ）</option>
                                        <option value="bushu03025">尸（かばね・かばねだれ）</option>
                                        <option value="bushu04022">歹 歺（かばねへん）</option>
                                        <option value="bushu10005">髟（かみかんむり・かみがしら）</option>
                                        <option value="bushu16002">龜 亀（かめ）</option>
                                        <option value="bushu07015">辛（からい）</option>
                                        <option value="bushu03010">巛 川（かわ）</option>
                                        <option value="bushu09008">革（かわへん）</option>
                                        <option value="bushu05022">瓦（かわら）</option>
                                        <option value="bushu03013">干（かん）</option>
                                        <option value="bushu05019">甘（かん）</option>
                                        <option value="bushu02005">凵（かんがまえ・かんにょう）</option>
                                        <option value="bushu04022">歹 歺（がつ・がつへん）</option>
                                        <option value="bushu02011">厂（がんだれ）</option>
                                        <option value="bushu04004">木（き）</option>
                                        <option value="bushu11002">黃 黄（き・きいろ）</option>
                                        <option value="bushu04002">气（きがまえ）</option>
                                        <option value="bushu02021">几（きにょう）</option>
                                        <option value="bushu10004">鬼（きにょう）</option>
                                        <option value="bushu04031">牙（きば・きばへん）</option>
                                        <option value="bushu12002">黍（きび）</option>
                                        <option value="bushu04004">木（きへん）</option>
                                        <option value="bushu04015">斤（きん）</option>
                                        <option value="bushu03019">巾（きんべん）</option>
                                        <option value="bushu06008">行（ぎょう・ぎょうがまえ）</option>
                                        <option value="bushu03021">彳（ぎょうにんべん）</option>
                                        <option value="bushu06001">艸 艹（くさ・くさかんむり）</option>
                                        <option value="bushu03034">屮（くさのめ）</option>
                                        <option value="bushu03003">口（くち・くちへん）</option>
                                        <option value="bushu03006">囗（くにがまえ）</option>
                                        <option value="bushu09003">首（くび）</option>
                                        <option value="bushu04029">比（くらべる）</option>
                                        <option value="bushu07003">車（くるま・くるまへん）</option>
                                        <option value="bushu11003">黑 黒（くろ・くろへん）</option>
                                        <option value="bushu05023">禸（ぐうのあし）</option>
                                        <option value="bushu04021">毛（け）</option>
                                        <option value="bushu03035">彑 彐（けいがしら）</option>
                                        <option value="bushu02001">冂（けいがまえ）</option>
                                        <option value="bushu02010">亠（けいさんかんむり）</option>
                                        <option value="bushu05015">皮（けがわ）</option>
                                        <option value="bushu04003">犬 犭（けものへん）</option>
                                        <option value="bushu04010">欠（けんづくり）</option>
                                        <option value="bushu05017">玄（げん）</option>
                                        <option value="bushu07007">言 訁（げん）</option>
                                        <option value="bushu03001">子（こ）</option>
                                        <option value="bushu03004">工（こう）</option>
                                        <option value="bushu04032">爻（こう）</option>
                                        <option value="bushu07001">貝（こがい）</option>
                                        <option value="bushu04016">心 忄（こころ）</option>
                                        <option value="bushu03024">阜 阝（こざと・こざとへん）</option>
                                        <option value="bushu07007">言 訁（ことば）</option>
                                        <option value="bushu03001">子（こども・こどもへん・こへん）</option>
                                        <option value="bushu03030">廾（こまぬき）</option>
                                        <option value="bushu06014">米（こめ・こめへん）</option>
                                        <option value="bushu07011">酉（こよみのとり）</option>
                                        <option value="bushu06017">衣 衤（ころも・ころもへん）</option>
                                        <option value="bushu06019">艮（こん・こんづくり）</option>
                                        <option value="bushu07007">言 訁（ごんべん）</option>
                                        <option value="bushu11001">魚（さかなへん）</option>
                                        <option value="bushu07011">酉（さけのとり）</option>
                                        <option value="bushu02014">匕（さじ・さじのひ）</option>
                                        <option value="bushu07010">里（さと・さとへん）</option>
                                        <option value="bushu03002">士（さむらい）</option>
                                        <option value="bushu05013">皿（さら）</option>
                                        <option value="bushu04007">水 氵 氺（さんずい）</option>
                                        <option value="bushu03020">彡（さんづくり）</option>
                                        <option value="bushu04027">支（し）</option>
                                        <option value="bushu11008">鹵（しお・しおへん）</option>
                                        <option value="bushu11006">鹿（しか）</option>
                                        <option value="bushu06024">而（しかして）</option>
                                        <option value="bushu03025">尸（しかばね・しかばねかんむり・しかばねだれ）</option>
                                        <option value="bushu11006">鹿（しかへん）</option>
                                        <option value="bushu03026">弋（しきがまえ）</option>
                                        <option value="bushu06024">而（しこうして）</option>
                                        <option value="bushu06022">舌（した）</option>
                                        <option value="bushu04016">心 忄（したごころ）</option>
                                        <option value="bushu06022">舌（したへん）</option>
                                        <option value="bushu04007">水 氵 氺（したみず）</option>
                                        <option value="bushu04027">支（しにょう）</option>
                                        <option value="bushu05011">示 礻（しめす・しめすへん）</option>
                                        <option value="bushu03008">小（しょう・しょうがしら）</option>
                                        <option value="bushu04033">爿（しょうへん）</option>
                                        <option value="bushu09004">食 飠（しょく・しょくへん）</option>
                                        <option value="bushu05006">白（しろ・しろへん）</option>
                                        <option value="bushu07015">辛（しん）</option>
                                        <option value="bushu07017">臣（しん）</option>
                                        <option value="bushu03015">辵 辶（しんにゅう・しんにょう）</option>
                                        <option value="bushu07014">辰（しんのたつ）</option>
                                        <option value="bushu02004">十（じゅう）</option>
                                        <option value="bushu05023">禸（じゅう・じゅうのあし）</option>
                                        <option value="bushu04027">支（じゅうまた）</option>
                                        <option value="bushu03017">夂 夊（すいにょう）</option>
                                        <option value="bushu06020">耒（すきへん）</option>
                                        <option value="bushu05021">无 旡（すでのつくり）</option>
                                        <option value="bushu03023">寸（すん・すんづくり）</option>
                                        <option value="bushu08009">齊 斉（せい）</option>
                                        <option value="bushu06001">艸 艹（そうこう）</option>
                                        <option value="bushu04030">爪 爫（そうにょう）</option>
                                        <option value="bushu07009">走（そうにょう）</option>
                                        <option value="bushu03009">夕（た）</option>
                                        <option value="bushu05005">田（た）</option>
                                        <option value="bushu08008">隶（たい）</option>
                                        <option value="bushu10001">高（たかい）</option>
                                        <option value="bushu03004">工（たくみ・たくみへん）</option>
                                        <option value="bushu06004">竹（たけ・たけかんむり）</option>
                                        <option value="bushu10008">鬥（たたかいがまえ）</option>
                                        <option value="bushu05008">立（たつ）</option>
                                        <option value="bushu07014">辰（たつ）</option>
                                        <option value="bushu16001">龍 竜（たつ）</option>
                                        <option value="bushu05008">立（たつへん）</option>
                                        <option value="bushu01003">丨（たてぼう）</option>
                                        <option value="bushu07008">谷（たに・たにへん）</option>
                                        <option value="bushu05005">田（たへん）</option>
                                        <option value="bushu05001">玉 王 ⺩（たま・たまへん）</option>
                                        <option value="bushu03011">大（だい）</option>
                                        <option value="bushu03032">尢 尣（だいのまげあし）</option>
                                        <option value="bushu03017">夂 夊（ち）</option>
                                        <option value="bushu06015">血（ち）</option>
                                        <option value="bushu12003">黹（ち）</option>
                                        <option value="bushu02009">力（ちから）</option>
                                        <option value="bushu04018">父（ちち）</option>
                                        <option value="bushu06015">血（ちへん）</option>
                                        <option value="bushu10006">鬯（ちょう）</option>
                                        <option value="bushu01004">丶（ちょぼ）</option>
                                        <option value="bushu03029">⺍（つ・つかんむり）</option>
                                        <option value="bushu04017">月（つき・つきへん）</option>
                                        <option value="bushu02021">几（つくえ）</option>
                                        <option value="bushu09008">革（つくりがわ）</option>
                                        <option value="#" selected>土（つち・つちへん）</option>
                                        <option value="bushu02020">勹（つつみがまえ）</option>
                                        <option value="bushu13001">鼓（つづみ）</option>
                                        <option value="bushu07006">角（つの・つのへん）</option>
                                        <option value="bushu04030">爪 爫（つめ・つめかんむり・つめがしら）</option>
                                        <option value="bushu01002">乙 乚（つりばり）</option>
                                        <option value="bushu04005">手 扌（て）</option>
                                        <option value="bushu03034">屮（てつ）</option>
                                        <option value="bushu04005">手 扌（てへん）</option>
                                        <option value="bushu01004">丶（てん）</option>
                                        <option value="bushu02022">卜（と）</option>
                                        <option value="bushu04013">戶 戸（と）</option>
                                        <option value="bushu04026">斗（と）</option>
                                        <option value="bushu10008">鬥（とうがまえ）</option>
                                        <option value="bushu04013">戶 戸（とかんむり・とだれ・とびらのと）</option>
                                        <option value="bushu09007">飛（とぶ）</option>
                                        <option value="bushu04026">斗（とます）</option>
                                        <option value="bushu04012">攴 攵（とまた）</option>
                                        <option value="bushu04006">止（とめへん・とめる）</option>
                                        <option value="bushu06025">虍（とら・とらかんむり・とらがしら）</option>
                                        <option value="bushu11004">鳥（とり）</option>
                                        <option value="bushu07011">酉（とりへん）</option>
                                        <option value="bushu11004">鳥（とりへん）</option>
                                        <option value="bushu02001">冂（どうがまえ）</option>
                                        <option value="#" selected>土（どへん）</option>
                                        <option value="bushu03008">小（なおがしら）</option>
                                        <option value="bushu04019">毋 母（なかれ）</option>
                                        <option value="bushu08005">長（ながい）</option>
                                        <option value="bushu05021">无 旡（なし）</option>
                                        <option value="bushu03017">夂 夊（なつあし）</option>
                                        <option value="bushu02010">亠（なべぶた）</option>
                                        <option value="bushu10007">韋（なめしがわ）</option>
                                        <option value="bushu04029">比（ならびひ）</option>
                                        <option value="bushu02003">二（に）</option>
                                        <option value="bushu10006">鬯（においざけ）</option>
                                        <option value="bushu06013">肉 月（にく・にくづき）</option>
                                        <option value="bushu06011">襾 西 覀（にし）</option>
                                        <option value="bushu03030">廾（にじゅうあし）</option>
                                        <option value="bushu02013">冫（にすい）</option>
                                        <option value="bushu04008">日（にち・にちへん）</option>
                                        <option value="bushu02007">入（にゅう）</option>
                                        <option value="bushu09010">韭（にら）</option>
                                        <option value="bushu02006">儿（にんにょう）</option>
                                        <option value="bushu02002">人 亻（にんべん）</option>
                                        <option value="bushu12003">黹（ぬいとり）</option>
                                        <option value="bushu13002">鼠（ねずみ・ねずみへん）</option>
                                        <option value="bushu06019">艮（ねづくり）</option>
                                        <option value="bushu05011">示 礻（ねへん）</option>
                                        <option value="bushu01006">丿（の）</option>
                                        <option value="bushu05009">禾（のぎ・のぎへん）</option>
                                        <option value="bushu07018">釆（のごめ・のごめへん）</option>
                                        <option value="bushu04030">爪 爫（のつ）</option>
                                        <option value="bushu04012">攴 攵（のぶん）</option>
                                        <option value="bushu02008">八（は）</option>
                                        <option value="bushu12001">齒 歯（は）</option>
                                        <option value="bushu02023">匚（はこがまえ）</option>
                                        <option value="bushu07009">走（はしる）</option>
                                        <option value="bushu02008">八（はち・はちがしら）</option>
                                        <option value="bushu05014">癶（はつがしら）</option>
                                        <option value="bushu14001">鼻（はな・はなへん）</option>
                                        <option value="bushu06006">羽 羽（はね）</option>
                                        <option value="bushu01005">亅（はねぼう）</option>
                                        <option value="bushu04019">毋 母（はは・ははのかん）</option>
                                        <option value="bushu03019">巾（はば・はばへん）</option>
                                        <option value="bushu12001">齒 歯（はへん）</option>
                                        <option value="bushu01006">丿（はらいぼう）</option>
                                        <option value="bushu11005">麥 麦（ばくにょう）</option>
                                        <option value="bushu02014">匕（ひ）</option>
                                        <option value="bushu04001">火 灬（ひ）</option>
                                        <option value="bushu04008">日（ひ）</option>
                                        <option value="bushu08007">非（ひ）</option>
                                        <option value="bushu05018">疋（ひき・ひきへん）</option>
                                        <option value="bushu06016">羊 ⺷（ひつじ・ひつじへん）</option>
                                        <option value="bushu02002">人 亻（ひと）</option>
                                        <option value="bushu02006">儿（ひとあし）</option>
                                        <option value="bushu02002">人 亻（ひとがしら・ひとやね）</option>
                                        <option value="bushu05015">皮（ひのかわ）</option>
                                        <option value="bushu04001">火 灬（ひへん）</option>
                                        <option value="bushu04008">日（ひへん）</option>
                                        <option value="bushu07011">酉（ひよみのとり）</option>
                                        <option value="bushu02018">冖（ひらかんむり）</option>
                                        <option value="bushu04014">曰（ひらび）</option>
                                        <option value="bushu02019">卩 㔾（ふしづくり）</option>
                                        <option value="bushu12003">黹（ふつへん）</option>
                                        <option value="bushu06027">聿（ふで・ふでづくり）</option>
                                        <option value="bushu06012">舟（ふね・ふねへん）</option>
                                        <option value="bushu03017">夂 夊（ふゆがしら）</option>
                                        <option value="bushu08006">隹（ふるとり）</option>
                                        <option value="bushu05021">无 旡（ぶ）</option>
                                        <option value="bushu07016">豕（ぶた）</option>
                                        <option value="bushu04009">文（ぶん・ぶんにょう）</option>
                                        <option value="bushu02018">冖（べきかんむり）</option>
                                        <option value="bushu13004">黽（べん）</option>
                                        <option value="bushu04020">方（ほう・ほうへん）</option>
                                        <option value="bushu04025">戈（ほこ）</option>
                                        <option value="bushu05020">矛（ほこ）</option>
                                        <option value="bushu04025">戈（ほこがまえ）</option>
                                        <option value="bushu04023">殳（ほこづくり）</option>
                                        <option value="bushu04025">戈（ほこづくり）</option>
                                        <option value="bushu05020">矛（ほこへん）</option>
                                        <option value="bushu03013">干（ほす）</option>
                                        <option value="bushu06026">缶（ほとぎ・ほとぎへん）</option>
                                        <option value="bushu10003">骨（ほね・ほねへん）</option>
                                        <option value="bushu01003">丨（ぼう）</option>
                                        <option value="bushu02022">卜（ぼく）</option>
                                        <option value="bushu04012">攴 攵（ぼくづくり・ぼくにょう）</option>
                                        <option value="bushu02022">卜（ぼくのと）</option>
                                        <option value="bushu07019">舛（まいあし）</option>
                                        <option value="bushu03010">巛 川（まがりがわ）</option>
                                        <option value="bushu02001">冂（まきがまえ）</option>
                                        <option value="bushu03032">尢 尣（まげあし）</option>
                                        <option value="bushu03010">巛 川（まげかわ）</option>
                                        <option value="bushu04032">爻（まじわる）</option>
                                        <option value="bushu07019">舛（ます）</option>
                                        <option value="bushu02015">又（また）</option>
                                        <option value="bushu03022">广（まだれ）</option>
                                        <option value="bushu07013">豆（まめ・まめへん）</option>
                                        <option value="bushu07012">身（み）</option>
                                        <option value="bushu04007">水 氵 氺（みず）</option>
                                        <option value="bushu06009">自（みずから）</option>
                                        <option value="bushu07012">身（みへん）</option>
                                        <option value="bushu06003">耳（みみ・みみへん）</option>
                                        <option value="bushu07002">見（みる）</option>
                                        <option value="bushu02017">厶（む）</option>
                                        <option value="bushu05021">无 旡（む）</option>
                                        <option value="bushu11005">麥 麦（むぎ・むぎへん）</option>
                                        <option value="bushu06005">虫（むし・むしへん）</option>
                                        <option value="bushu07020">豸（むじな・むじなへん）</option>
                                        <option value="bushu05021">无 旡（むにょう）</option>
                                        <option value="bushu05020">矛（むのほこ）</option>
                                        <option value="bushu03027">邑 阝（むら）</option>
                                        <option value="bushu05007">目 罒（め）</option>
                                        <option value="bushu03034">屮（めばえ）</option>
                                        <option value="bushu05007">目 罒（めへん）</option>
                                        <option value="bushu04032">爻（めめ）</option>
                                        <option value="bushu09006">面（めん）</option>
                                        <option value="bushu05012">用（もちいる）</option>
                                        <option value="bushu08004">門（もん・もんがまえ）</option>
                                        <option value="bushu05010">矢（や）</option>
                                        <option value="bushu17001">龠（やく・やくのふえ）</option>
                                        <option value="bushu05010">矢（やへん）</option>
                                        <option value="bushu03005">山（やま）</option>
                                        <option value="bushu05016">疒（やまいだれ）</option>
                                        <option value="bushu03005">山（やまかんむり・やまへん）</option>
                                        <option value="bushu03009">夕（ゆう・ゆうべ）</option>
                                        <option value="bushu06008">行（ゆきがまえ）</option>
                                        <option value="bushu03014">弓（ゆみ・ゆみへん）</option>
                                        <option value="bushu03033">幺（よう）</option>
                                        <option value="bushu03026">弋（よく）</option>
                                        <option value="bushu06020">耒（らいすき）</option>
                                        <option value="bushu04016">心 忄（りっしんべん）</option>
                                        <option value="bushu02012">刀 刂（りっとう）</option>
                                        <option value="bushu16001">龍 竜（りゅう）</option>
                                        <option value="bushu04023">殳（るまた）</option>
                                        <option value="bushu08008">隶（れいづくり）</option>
                                        <option value="bushu10009">鬲（れき）</option>
                                        <option value="bushu04001">火 灬（れっか・れんが）</option>
                                        <option value="bushu11008">鹵（ろ）</option>
                                        <option value="bushu02018">冖（わかんむり）</option>
                                        <option value="bushu02019">卩 㔾（わりふ）</option>
                                   </select>
                              </div>
                         </div><!--search_narrowdown-->
                         <div class="search_data bushu_menu">
                              <ul class="search_menu">
                                   <li>画数順</li>
                                   <li><a href="bbushu03012">漢検級順</a></li>
                                   <li><a href="cbushu03012">読み順</a></li>
                              </ul>
                              <ul class="search_menu2">
                                   <li><a href="#parts03">3画</a></li>
                                   <li><a href="#parts04">4画</a></li>
                                   <li><a href="#parts05">5画</a></li>
                                   <li><a href="#parts06">6画</a></li>
                                   <li><a href="#parts07">7画</a></li>
                                   <li><a href="#parts08">8画</a></li>
                                   <li><a href="#parts09">9画</a></li>
                                   <li><a href="#parts10">10画</a></li>
                                   <li><a href="#parts11">11画</a></li>
                                   <li><a href="#parts12">12画</a></li>
                                   <li><a href="#parts13">13画</a></li>
                                   <li><a href="#parts14">14画</a></li>
                                   <li><a href="#parts15">15画</a></li>
                                   <li><a href="#parts16">16画</a></li>
                                   <li><a href="#parts17">17画</a></li>
                                   <li><a href="#parts18">18画</a></li>
                                   <li><a href="#parts19">19画</a></li>
                                   <li><a href="#parts20">20画</a></li>
                                   <li><a href="#parts22">22画</a></li>
                                   <li><a href="#parts23">23画</a></li>
                                   <li><a href="#parts24">24画</a></li>
                                   <li><a href="#parts25">25画</a></li>
                              </ul>
                         </div><!--search_data-->
                        
                         <h2 class="left_border">部首：土部（つち・つちへん・どへん）の漢字一覧</h2>
                         <div class="bushu_wrap">
                              <div class="color_info">
                                   <ul>
                                        <li><span>常用漢字の背景色＝</span><span class="color1"></span></li>
                                        <li><span>人名用漢字の背景色＝</span><span class="color2"></span></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts03">
                                   <h3 class="ttl_while"><a href="kakusu03">３画</a></h3>
                                   <ul class="search_parts">
                                        <li><a class="color1" href="kanji/063">土</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts04">
                                   <h3 class="ttl_while"><a href="kakusu04">４画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13630">圠</a></li>
                                        <li><a href="kanjiy/13631">圡</a></li>
                                        <li><a href="kanjiy/26238">龶</a></li>
                                        <li><a href="kanjiy/27696">𡈽</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts05">
                                   <h3 class="ttl_while"><a href="kakusu05">５画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13632">圢</a></li>
                                        <li><a href="kanjiy/13633">圣</a></li>
                                        <li><a href="kanjiy/19033">㘦</a></li>
                                        <li><a href="kanjiy/13634">圤</a></li>
                                        <li><a href="kanjiy/13635">圥</a></li>
                                        <li><a class="color1" href="640">圧</a></li>
                                        <li><a href="3329">圦</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts06">
                                   <h3 class="ttl_while"><a href="kakusu06">６画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13636">圩</a></li>
                                        <li><a href="kanjiy/13637">圪</a></li>
                                        <li><a href="kanjiy/13638">圫</a></li>
                                        <li><a href="kanjiy/13639">圬</a></li>
                                        <li><a href="kanjiy/13640">圮</a></li>
                                        <li><a href="kanjiy/13641">圯</a></li>
                                        <li><a href="kanjiy/13642">圱</a></li>
                                        <li><a href="kanjiy/13643">圲</a></li>
                                        <li><a href="kanjiy/13644">圳</a></li>
                                        <li><a href="kanjiy/13645">圴</a></li>
                                        <li><a href="kanjiy/13646">圵</a></li>
                                        <li><a href="kanjiy/13647">圶</a></li>
                                        <li><a href="kanjiy/24973">圹</a></li>
                                        <li><a href="kanjiy/24974">场</a></li>
                                        <li><a class="color1" href="kanji/186">地</a></li>
                                        <li><a class="color1" href="710">在</a></li>
                                        <li><a href="kanjiy/27796">𡉕</a></li>
                                        <li><a class="color2" href="2350">圭</a>
                                        </li>
                                        <li><a href="5681">赱</a></li>
                                        <li><a href="5788">圷</a></li>
                                        <li><a href="5789">圸</a></li>
                                   </ul>
                              </div>
                         
                              <div class="parts_box" id="parts07">
                                   <h3 class="ttl_while"><a href="kakusu07">７画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="7915">㘫</a></li>
                                        <li><a href="kanjiy/19034">㘧</a></li>
                                        <li><a href="kanjiy/19035">㘨</a></li>
                                        <li><a href="kanjiy/19036">㘩</a></li>
                                        <li><a href="kanjiy/19037">㘪</a></li>
                                        <li><a href="kanjiy/19038">㘬</a></li>
                                        <li><a href="kanjiy/19039">㘭</a></li>
                                        <li><a href="kanjiy/19040">㘰</a></li>
                                        <li><a href="kanjiy/13648">圼</a></li>
                                        <li><a href="kanjiy/13649">圽</a></li>
                                        <li><a href="kanjiy/13650">圾</a></li>
                                        <li><a href="kanjiy/13651">圿</a></li>
                                        <li><a href="kanjiy/13652">坁</a></li>
                                        <li><a href="kanjiy/13653">坃</a></li>
                                        <li><a href="kanjiy/13654">坄</a></li>
                                        <li><a href="kanjiy/13655">坅</a></li>
                                        <li><a href="kanjiy/13656">坆</a></li>
                                        <li><a href="kanjiy/13657">坉</a></li>
                                        <li><a href="kanjiy/13658">坋</a></li>
                                        <li><a href="kanjiy/13659">坌</a></li>
                                        <li><a href="kanjiy/13660">坍</a></li>
                                        <li><a href="kanjiy/13661">坒</a></li>
                                        <li><a href="kanjiy/13662">坓</a></li>
                                        <li><a href="kanjiy/13663">坔</a></li>
                                        <li><a href="kanjiy/13664">坕</a></li>
                                        <li><a href="kanjiy/13665">坖</a></li>
                                        <li><a href="kanjiy/13666">块</a></li>
                                        <li><a href="kanjiy/13667">坘</a></li>
                                        <li><a href="kanjiy/23927">坈</a></li>
                                        <li><a href="kanjiy/24975">坛</a></li>
                                        <li><a href="kanjiy/24976">坜</a></li>
                                        <li><a href="kanjiy/24978">坟</a></li>
                                        <li><a class="color1" href="kanji/394">坂</a></li>
                                        <li><a class="color1" href="680">均</a></li>
                                        <li><a href="kanjiy/26631">㘮</a></li>
                                        <li><a href="kanjiy/26632">㘯</a></li>
                                        <li><a class="color1" href="1270">坊</a>
                                        </li>
                                        <li><a class="color1" href="1405">坑</a>
                                        </li>
                                        <li><a href="kanjiy/27797">𡉻</a></li>
                                        <li><a href="kanjiy/27798">𡉴</a></li>
                                        <li><a class="color2" href="2439">坐</a>
                                        </li>
                                        <li><a href="3330">坎</a></li>
                                        <li><a href="3331">圻</a></li>
                                        <li><a href="3332">址</a></li>
                                        <li><a href="3333">坏</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts08">
                                   <h3 class="ttl_while"><a href="kakusu08">８画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6594">坵</a></li>
                                        <li><a href="kanjiy/19041">㘱</a></li>
                                        <li><a href="kanjiy/19042">㘲</a></li>
                                        <li><a href="kanjiy/19043">㘳</a></li>
                                        <li><a href="kanjiy/19045">㘷</a></li>
                                        <li><a href="kanjiy/13670">坢</a></li>
                                        <li><a href="kanjiy/13671">坣</a></li>
                                        <li><a href="kanjiy/13672">坥</a></li>
                                        <li><a href="kanjiy/13673">坧</a></li>
                                        <li><a href="kanjiy/13674">坨</a></li>
                                        <li><a href="kanjiy/13675">坫</a></li>
                                        <li><a href="kanjiy/13677">坭</a></li>
                                        <li><a href="kanjiy/13678">坮</a></li>
                                        <li><a href="kanjiy/13679">坯</a></li>
                                        <li><a href="kanjiy/13680">坰</a></li>
                                        <li><a href="kanjiy/13681">坱</a></li>
                                        <li><a href="kanjiy/13682">坲</a></li>
                                        <li><a href="kanjiy/13683">坳</a></li>
                                        <li><a href="kanjiy/13684">坴</a></li>
                                        <li><a href="kanjiy/13685">坶</a></li>
                                        <li><a href="kanjiy/13686">坷</a></li>
                                        <li><a href="kanjiy/13687">坸</a></li>
                                        <li><a href="kanjiy/13688">坹</a></li>
                                        <li><a href="kanjiy/13689">坺</a></li>
                                        <li><a href="kanjiy/13690">坻</a></li>
                                        <li><a href="kanjiy/13691">坼</a></li>
                                        <li><a href="kanjiy/13692">坽</a></li>
                                        <li><a href="kanjiy/13693">坾</a></li>
                                        <li><a href="kanjiy/13694">垀</a></li>
                                        <li><a href="kanjiy/13695">垁</a></li>
                                        <li><a href="kanjiy/13696">垃</a></li>
                                        <li><a href="kanjiy/24200">㘴</a></li>
                                        <li><a href="kanjiy/24979">坠</a></li>
                                        <li><a href="kanjiy/24980">垆</a></li>
                                        <li><a href="kanjiy/24981">垇</a></li>
                                        <li><a href="kanjiy/24982">垊</a></li>
                                        <li><a class="color1" href="917">垂</a></li>
                                        <li><a href="kanjiy/26633">㘵</a></li>
                                        <li><a class="color1" href="1825">坪</a>
                                        </li>
                                        <li><a class="color2" href="2326">尭</a>
                                        </li>
                                        <li><a href="2426">坤</a></li>
                                        <li><a class="color2" href="2710">坦</a>
                                        </li>
                                        <li><a href="3334">坩</a></li>
                                        <li><a href="3335">坡</a></li>
                                        <li><a href="3336">坿</a></li>
                                        <li><a href="5967">垈</a></li>
                                        <li><a href="5968">垉</a></li>
                                   </ul>
                              </div>
                         
                              <div class="parts_box" id="parts09">
                                   <h3 class="ttl_while"><a href="kakusu09">９画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/19046">㘸</a></li>
                                        <li><a href="kanjiy/19047">㘹</a></li>
                                        <li><a href="kanjiy/19048">㘺</a></li>
                                        <li><a href="kanjiy/19049">㘻</a></li>
                                        <li><a href="kanjiy/13676">坬</a></li>
                                        <li><a href="kanjiy/13697">垌</a></li>
                                        <li><a href="kanjiy/13698">垍</a></li>
                                        <li><a href="kanjiy/13699">垎</a></li>
                                        <li><a href="kanjiy/13700">垏</a></li>
                                        <li><a href="kanjiy/13701">垐</a></li>
                                        <li><a href="kanjiy/13702">垑</a></li>
                                        <li><a href="kanjiy/13703">垒</a></li>
                                        <li><a href="kanjiy/13704">垕</a></li>
                                        <li><a href="kanjiy/23928">垔</a></li>
                                        <li><a href="kanjiy/13705">垖</a></li>
                                        <li><a href="kanjiy/23929">垝</a></li>
                                        <li><a href="kanjiy/13706">垗</a></li>
                                        <li><a href="kanjiy/13707">垘</a></li>
                                        <li><a href="kanjiy/13708">垙</a></li>
                                        <li><a href="kanjiy/13709">垚</a></li>
                                        <li><a href="kanjiy/13710">垛</a></li>
                                        <li><a href="kanjiy/13711">垜</a></li>
                                        <li><a href="kanjiy/13712">垞</a></li>
                                        <li><a href="kanjiy/13713">垟</a></li>
                                        <li><a href="kanjiy/13714">垡</a></li>
                                        <li><a href="kanjiy/13715">垥</a></li>
                                        <li><a href="kanjiy/13716">垦</a></li>
                                        <li><a href="kanjiy/13717">垧</a></li>
                                        <li><a href="kanjiy/13718">垨</a></li>
                                        <li><a href="kanjiy/13719">垩</a></li>
                                        <li><a href="kanjiy/13720">垬</a></li>
                                        <li><a href="kanjiy/24983">垫</a></li>
                                        <li><a href="kanjiy/24985">垮</a></li>
                                        <li><a href="kanjiy/24988">垱</a></li>
                                        <li><a href="kanjiy/24990">垲</a></li>
                                        <li><a href="kanjiy/24991">垴</a></li>
                                        <li><a href="kanjiy/24993">垵</a></li>
                                        <li><a class="color1" href="kanji/490">型</a></li>
                                        <li><a class="color1" href="912">城</a></li>
                                        <li><a href="kanjiy/26634">㘼</a></li>
                                        <li><a href="kanjiy/26635">㘾</a></li>
                                        <li><a href="kanjiy/26636">㘽</a></li>
                                        <li><a class="color1" href="1626">垣</a>
                                        </li>
                                        <li><a href="kanjiy/27799">𡋤</a></li>
                                        <li><a href="kanjiy/27800">𡋗</a></li>
                                        <li><a href="2336">垢</a></li>
                                        <li><a href="3337">垓</a></li>
                                        <li><a href="3338">垠</a></li>
                                        <li><a href="3339">垤</a></li>
                                        <li><a href="5969">垳</a></li>
                                        <li><a href="5970">垪</a></li>
                                        <li><a href="5971">垰</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts10">
                                   <h3 class="ttl_while"><a href="kakusu10">１０画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6307">袁</a></li>
                                        <li><a href="kanjiy/18634">﨏</a></li>
                                        <li><a href="kanjiy/19044">㘶</a></li>
                                        <li><a href="kanjiy/19050">㘿</a></li>
                                        <li><a href="kanjiy/19051">㙀</a></li>
                                        <li><a href="kanjiy/19052">㙁</a></li>
                                        <li><a href="kanjiy/19053">㙂</a></li>
                                        <li><a href="kanjiy/19054">㙃</a></li>
                                        <li><a href="kanjiy/19055">㙅</a></li>
                                        <li><a href="kanjiy/24201">㙄</a></li>
                                        <li><a href="kanjiy/13721">垶</a></li>
                                        <li><a href="kanjiy/13722">垷</a></li>
                                        <li><a href="kanjiy/13723">垸</a></li>
                                        <li><a href="kanjiy/13724">垹</a></li>
                                        <li><a href="kanjiy/13725">垺</a></li>
                                        <li><a href="kanjiy/13726">垻</a></li>
                                        <li><a href="kanjiy/13727">垼</a></li>
                                        <li><a href="kanjiy/13728">垽</a></li>
                                        <li><a href="kanjiy/24986">垯</a></li>
                                        <li><a href="kanjiy/13729">垾</a></li>
                                        <li><a href="kanjiy/13730">垿</a></li>
                                        <li><a href="kanjiy/13731">埁</a></li>
                                        <li><a href="kanjiy/13732">埂</a></li>
                                        <li><a href="kanjiy/13733">埄</a></li>
                                        <li><a href="kanjiy/13734">埅</a></li>
                                        <li><a href="kanjiy/13735">埇</a></li>
                                        <li><a href="kanjiy/13736">埈</a></li>
                                        <li><a href="kanjiy/24994">埘</a></li>
                                        <li><a href="kanjiy/13737">埉</a></li>
                                        <li><a href="kanjiy/24995">埚</a></li>
                                        <li><a href="kanjiy/13738">埊</a></li>
                                        <li><a href="kanjiy/24996">埛</a></li>
                                        <li><a href="kanjiy/13739">埌</a></li>
                                        <li><a href="kanjiy/13740">埍</a></li>
                                        <li><a href="kanjiy/13741">埏</a></li>
                                        <li><a href="kanjiy/13742">埐</a></li>
                                        <li><a href="kanjiy/13743">埑</a></li>
                                        <li><a href="kanjiy/13744">埕</a></li>
                                        <li><a href="kanjiy/13745">埗</a></li>
                                        <li><a href="kanjiy/26645">㙆</a></li>
                                        <li><a class="color1" href="1571">埋</a>
                                        </li>
                                        <li><a href="kanjiy/27697">𡌛</a></li>
                                        <li><a href="kanjiy/27802">𡋽</a></li>
                                        <li><a href="3340">埃</a></li>
                                        <li><a href="3341">埆</a></li>
                                        <li><a href="3342">埒</a></li>
                                        <li><a href="5883">埔</a></li>
                                        <li><a href="5966">埀</a></li>
                                        <li><a href="5972">埓</a></li>
                                        <li><a href="6075">埖</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts11">
                                   <h3 class="ttl_while"><a href="kakusu11">１１画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6542">埳</a></li>
                                        <li><a href="kanjiy/19056">㙇</a></li>
                                        <li><a href="kanjiy/19057">㙈</a></li>
                                        <li><a href="kanjiy/19058">㙉</a></li>
                                        <li><a href="kanjiy/19059">㙊</a></li>
                                        <li><a href="kanjiy/23930">埶</a></li>
                                        <li><a href="kanjiy/23931">埸</a></li>
                                        <li><a href="kanjiy/24997">堎</a></li>
                                        <li><a href="kanjiy/24998">堏</a></li>
                                        <li><a href="kanjiy/24999">堐</a></li>
                                        <li><a href="kanjiy/25000">堒</a></li>
                                        <li><a href="kanjiy/25001">堓</a></li>
                                        <li><a href="kanjiy/25002">堔</a></li>
                                        <li><a href="kanjiy/13746">埝</a></li>
                                        <li><a href="kanjiy/13747">埞</a></li>
                                        <li><a href="kanjiy/13748">埡</a></li>
                                        <li><a href="kanjiy/13749">埢</a></li>
                                        <li><a href="kanjiy/13750">埤</a></li>
                                        <li><a href="kanjiy/13751">埥</a></li>
                                        <li><a href="kanjiy/13752">埦</a></li>
                                        <li><a class="color1" href="582">堂</a></li>
                                        <li><a href="kanjiy/13753">埧</a></li>
                                        <li><a href="kanjiy/13754">埨</a></li>
                                        <li><a class="color1" href="670">基</a></li>
                                        <li><a href="kanjiy/13755">埩</a></li>
                                        <li><a href="kanjiy/13756">埪</a></li>
                                        <li><a href="kanjiy/13757">埫</a></li>
                                        <li><a href="kanjiy/13758">埬</a></li>
                                        <li><a href="kanjiy/13759">埭</a></li>
                                        <li><a href="kanjiy/13760">埮</a></li>
                                        <li><a href="kanjiy/13761">埯</a></li>
                                        <li><a class="color1" href="826">域</a></li>
                                        <li><a href="kanjiy/13762">埰</a></li>
                                        <li><a href="kanjiy/13763">埱</a></li>
                                        <li><a href="kanjiy/13764">埲</a></li>
                                        <li><a href="kanjiy/13765">埵</a></li>
                                        <li><a href="kanjiy/13766">埻</a></li>
                                        <li><a class="color1" href="1118">執</a>
                                        </li>
                                        <li><a href="kanjiy/13767">埽</a></li>
                                        <li><a href="kanjiy/13768">埾</a></li>
                                        <li><a href="kanjiy/13769">埿</a></li>
                                        <li><a href="kanjiy/13770">堁</a></li>
                                        <li><a href="kanjiy/13771">堃</a></li>
                                        <li><a href="kanjiy/13772">堄</a></li>
                                        <li><a href="kanjiy/13773">堇</a></li>
                                        <li><a href="kanjiy/13774">堈</a></li>
                                        <li><a href="kanjiy/26646">㙋</a></li>
                                        <li><a href="kanjiy/13775">堉</a></li>
                                        <li><a href="kanjiy/26647">㙌</a></li>
                                        <li><a href="kanjiy/13776">堌</a></li>
                                        <li><a href="kanjiy/26648">㙍</a></li>
                                        <li><a href="kanjiy/13777">堍</a></li>
                                        <li><a class="color1" href="1856">培</a>
                                        </li>
                                        <li><a class="color1" href="1898">堀</a>
                                        </li>
                                        <li><a class="color1" href="2010">埼</a>
                                        </li>
                                        <li><a class="color1" href="2053">堆</a>
                                        </li>
                                        <li><a href="kanjiy/27803">𡌶</a></li>
                                        <li><a href="kanjiy/27804">𡍄</a></li>
                                        <li><a class="color2" href="2590">埴</a>
                                        </li>
                                        <li><a href="2872">埠</a></li>
                                        <li><a class="color2" href="3028">埜</a>
                                        </li>
                                        <li><a href="3343">堊</a></li>
                                        <li><a href="3344">堋</a></li>
                                        <li><a href="6076">埣</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts12">
                                   <h3 class="ttl_while"><a href="kakusu12">１２画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6137">壻</a></li>
                                        <li><a href="7947">堦</a></li>
                                        <li><a href="8782">㙒</a></li>
                                        <li><a href="kanjiy/19060">㙎</a></li>
                                        <li><a href="kanjiy/19061">㙏</a></li>
                                        <li><a href="kanjiy/19062">㙐</a></li>
                                        <li><a href="kanjiy/19063">㙑</a></li>
                                        <li><a href="kanjiy/19064">㙓</a></li>
                                        <li><a href="kanjiy/19066">㙕</a></li>
                                        <li><a href="kanjiy/23932">堟</a></li>
                                        <li><a href="kanjiy/24992">堖</a></li>
                                        <li><a href="kanjiy/25003">塂</a></li>
                                        <li><a href="kanjiy/25004">塃</a></li>
                                        <li><a href="kanjiy/25005">塄</a></li>
                                        <li><a class="color1" href="kanji/161">場</a></li>
                                        <li><a href="kanjiy/25006">塅</a></li>
                                        <li><a href="kanjiy/25007">塆</a></li>
                                        <li><a href="kanjiy/25009">塇</a></li>
                                        <li><a href="kanjiy/25013">塭</a></li>
                                        <li><a class="color1" href="809">報</a></li>
                                        <li><a class="color1" href="1082">堅</a>
                                        </li>
                                        <li><a class="color1" href="1196">堤</a>
                                        </li>
                                        <li><a class="color1" href="1210">塔</a>
                                        </li>
                                        <li><a href="kanjiy/26656">㙖</a></li>
                                        <li><a href="kanjiy/13778">堗</a></li>
                                        <li><a href="kanjiy/26659">㙗</a></li>
                                        <li><a href="kanjiy/13779">堘</a></li>
                                        <li><a href="kanjiy/26661">㙘</a></li>
                                        <li><a href="kanjiy/13780">堚</a></li>
                                        <li><a href="kanjiy/13781">堛</a></li>
                                        <li><a class="color1" href="1641">堪</a>
                                        </li>
                                        <li><a href="kanjiy/13782">堜</a></li>
                                        <li><a href="kanjiy/13783">堞</a></li>
                                        <li><a href="kanjiy/13784">堠</a></li>
                                        <li><a href="kanjiy/13785">堢</a></li>
                                        <li><a class="color1" href="1805">堕</a>
                                        </li>
                                        <li><a href="kanjiy/13786">堣</a></li>
                                        <li><a class="color1" href="1823">塚</a>
                                        </li>
                                        <li><a href="kanjiy/13787">堥</a></li>
                                        <li><a href="kanjiy/13788">堧</a></li>
                                        <li><a href="kanjiy/13789">堨</a></li>
                                        <li><a class="color1" href="1884">塀</a>
                                        </li>
                                        <li><a href="kanjiy/13790">堩</a></li>
                                        <li><a href="kanjiy/13791">堫</a></li>
                                        <li><a class="color1" href="1933">塁</a>
                                        </li>
                                        <li><a href="kanjiy/13792">堬</a></li>
                                        <li><a href="kanjiy/13793">堭</a></li>
                                        <li><a href="kanjiy/13794">堮</a></li>
                                        <li><a href="kanjiy/13795">堲</a></li>
                                        <li><a href="kanjiy/13796">堳</a></li>
                                        <li><a class="color2" href="2183">堰</a>
                                        </li>
                                        <li><a href="kanjiy/13797">堶</a></li>
                                        <li><a class="color2" href="2223">堺</a>
                                        </li>
                                        <li><a href="kanjiy/13798">堷</a></li>
                                        <li><a href="kanjiy/13799">堸</a></li>
                                        <li><a href="kanjiy/13800">堹</a></li>
                                        <li><a href="kanjiy/13801">堻</a></li>
                                        <li><a href="kanjiy/13802">堼</a></li>
                                        <li><a href="kanjiy/13803">堾</a></li>
                                        <li><a href="kanjiy/13804">堿</a></li>
                                        <li><a class="color2" href="2779">堵</a>
                                        </li>
                                        <li><a href="3345">堙</a></li>
                                        <li><a href="3346">堝</a></li>
                                        <li><a href="3347">堡</a></li>
                                        <li><a class="color2" href="5765">堯</a>
                                        </li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts13">
                                   <h3 class="ttl_while"><a href="kakusu13">１３画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6078">塢</a></li>
                                        <li><a href="6079">塰</a></li>
                                        <li><a href="kanjiy/13869">墷</a></li>
                                        <li><a class="color1" href="6469">塡</a>
                                        </li>
                                        <li><a href="kanjiy/12344">塤</a></li>
                                        <li><a href="kanjiy/19065">㙔</a></li>
                                        <li><a href="kanjiy/19067">㙙</a></li>
                                        <li><a href="kanjiy/19068">㙚</a></li>
                                        <li><a href="kanjiy/19069">㙛</a></li>
                                        <li><a href="kanjiy/19070">㙝</a></li>
                                        <li><a href="kanjiy/19071">㙞</a></li>
                                        <li><a class="color1" href="kanji/450">塩</a></li>
                                        <li><a href="kanjiy/25010">塈</a></li>
                                        <li><a href="kanjiy/25011">塪</a></li>
                                        <li><a href="kanjiy/25012">塬</a></li>
                                        <li><a href="kanjiy/25014">塮</a></li>
                                        <li><a href="kanjiy/25015">塯</a></li>
                                        <li><a class="color1" href="807">墓</a></li>
                                        <li><a href="kanjiy/26246">塚</a></li>
                                        <li><a class="color1" href="1339">塊</a>
                                        </li>
                                        <li><a class="color1" href="1517">塗</a>
                                        </li>
                                        <li><a href="kanjiy/26662">㙜</a></li>
                                        <li><a class="color1" href="1793">塑</a>
                                        </li>
                                        <li><a class="color1" href="2009">塞</a>
                                        </li>
                                        <li><a href="2068">填</a></li>
                                        <li><a class="color2" href="2238">塙</a>
                                        </li>
                                        <li><a href="kanjiy/27805">𡏄</a></li>
                                        <li><a href="kanjiy/13805">塉</a></li>
                                        <li><a href="kanjiy/13806">塌</a></li>
                                        <li><a href="kanjiy/13807">塍</a></li>
                                        <li><a href="kanjiy/13808">塎</a></li>
                                        <li><a href="kanjiy/13809">塏</a></li>
                                        <li><a href="2783">塘</a></li>
                                        <li><a href="kanjiy/13810">塐</a></li>
                                        <li><a href="kanjiy/13811">塓</a></li>
                                        <li><a href="kanjiy/13812">塕</a></li>
                                        <li><a href="3037">堽</a></li>
                                        <li><a href="kanjiy/13813">塖</a></li>
                                        <li><a href="kanjiy/13814">塛</a></li>
                                        <li><a href="kanjiy/13815">塜</a></li>
                                        <li><a href="kanjiy/13816">塝</a></li>
                                        <li><a href="kanjiy/13817">塠</a></li>
                                        <li><a href="kanjiy/13818">塣</a></li>
                                        <li><a href="kanjiy/13819">塥</a></li>
                                        <li><a href="kanjiy/13820">塦</a></li>
                                        <li><a href="kanjiy/13821">塧</a></li>
                                        <li><a href="kanjiy/13822">塨</a></li>
                                        <li><a href="kanjiy/13829">塻</a></li>
                                        <li><a href="3348">塋</a></li>
                                        <li><a href="3349">塒</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts14">
                                   <h3 class="ttl_while"><a href="kakusu14">１４画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6077">塲</a></li>
                                        <li><a href="kanjiy/12342">塿</a></li>
                                        <li><a href="kanjiy/19072">㙠</a></li>
                                        <li><a href="kanjiy/19073">㙡</a></li>
                                        <li><a href="kanjiy/19074">㙢</a></li>
                                        <li><a href="kanjiy/19075">㙣</a></li>
                                        <li><a href="kanjiy/19076">㙤</a></li>
                                        <li><a href="kanjiy/19077">㙥</a></li>
                                        <li><a href="kanjiy/23934">墍</a></li>
                                        <li><a class="color1" href="679">境</a></li>
                                        <li><a href="kanjiy/25016">塱</a></li>
                                        <li><a class="color1" href="760">増</a></li>
                                        <li><a href="kanjiy/25017">墘</a></li>
                                        <li><a href="kanjiy/25018">墙</a></li>
                                        <li><a href="kanjiy/25019">墚</a></li>
                                        <li><a href="kanjiy/25020">墛</a></li>
                                        <li><a href="kanjiy/26349">塀</a></li>
                                        <li><a class="color1" href="1567">墨</a>
                                        </li>
                                        <li><a href="kanjiy/26666">㙟</a></li>
                                        <li><a href="kanjiy/26670">㙦</a></li>
                                        <li><a class="color1" href="1732">塾</a>
                                        </li>
                                        <li><a href="2604">塵</a></li>
                                        <li><a href="kanjiy/13823">塳</a></li>
                                        <li><a href="kanjiy/13824">塴</a></li>
                                        <li><a href="kanjiy/13825">塶</a></li>
                                        <li><a href="kanjiy/13826">塷</a></li>
                                        <li><a href="kanjiy/13827">塸</a></li>
                                        <li><a href="kanjiy/13828">塺</a></li>
                                        <li><a href="kanjiy/13830">塼</a></li>
                                        <li><a href="kanjiy/13831">塽</a></li>
                                        <li><a href="kanjiy/13832">墁</a></li>
                                        <li><a href="kanjiy/13833">墂</a></li>
                                        <li><a href="kanjiy/13834">墄</a></li>
                                        <li><a href="3350">塹</a></li>
                                        <li><a href="kanjiy/13835">墆</a></li>
                                        <li><a href="3351">墅</a></li>
                                        <li><a href="kanjiy/13836">墇</a></li>
                                        <li><a href="kanjiy/13837">墈</a></li>
                                        <li><a href="kanjiy/13838">墉</a></li>
                                        <li><a href="kanjiy/13839">墊</a></li>
                                        <li><a href="kanjiy/13840">墋</a></li>
                                        <li><a href="kanjiy/13841">墌</a></li>
                                        <li><a href="kanjiy/13842">墎</a></li>
                                        <li><a href="kanjiy/13843">墏</a></li>
                                        <li><a href="kanjiy/13844">墐</a></li>
                                        <li><a href="kanjiy/13845">墑</a></li>
                                        <li><a href="kanjiy/13846">墒</a></li>
                                        <li><a href="kanjiy/13847">墔</a></li>
                                        <li><a href="kanjiy/13848">墕</a></li>
                                        <li><a href="kanjiy/13849">墖</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts15">
                                   <h3 class="ttl_while"><a href="kakusu15">１５画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13860">墪</a></li>
                                        <li><a href="kanjiy/13861">墬</a></li>
                                        <li><a href="kanjiy/13862">墭</a></li>
                                        <li><a href="kanjiy/13863">墯</a></li>
                                        <li><a href="kanjiy/13864">墰</a></li>
                                        <li><a href="kanjiy/13865">墱</a></li>
                                        <li><a href="6149">墹</a></li>
                                        <li><a href="kanjiy/13866">墲</a></li>
                                        <li><a href="6150">墫</a></li>
                                        <li><a href="kanjiy/13867">墴</a></li>
                                        <li><a href="kanjiy/13868">墵</a></li>
                                        <li><a href="6152">墸</a></li>
                                        <li><a class="color2" href="6380">墨</a>
                                        </li>
                                        <li><a class="color2" href="6419">增</a>
                                        </li>
                                        <li><a href="8781">壄</a></li>
                                        <li><a href="kanjiy/19078">㙧</a></li>
                                        <li><a href="kanjiy/19079">㙨</a></li>
                                        <li><a href="kanjiy/19080">㙩</a></li>
                                        <li><a href="kanjiy/19081">㙪</a></li>
                                        <li><a href="kanjiy/19082">㙫</a></li>
                                        <li><a href="kanjiy/19083">㙬</a></li>
                                        <li><a href="kanjiy/23933">墀</a></li>
                                        <li><a class="color1" href="1511">墜</a>
                                        </li>
                                        <li><a class="color1" href="1547">墳</a>
                                        </li>
                                        <li><a href="kanjiy/26672">㙭</a></li>
                                        <li><a href="kanjiy/26674">㙮</a></li>
                                        <li><a href="3352">墟</a></li>
                                        <li><a href="5767">墮</a></li>
                                        <li><a href="kanjiy/13850">墝</a></li>
                                        <li><a href="kanjiy/13851">墠</a></li>
                                        <li><a href="kanjiy/13852">墡</a></li>
                                        <li><a href="kanjiy/13853">墢</a></li>
                                        <li><a href="kanjiy/13854">墣</a></li>
                                        <li><a href="kanjiy/13855">墤</a></li>
                                        <li><a href="kanjiy/13856">墥</a></li>
                                        <li><a href="kanjiy/13857">墦</a></li>
                                        <li><a href="kanjiy/13858">墧</a></li>
                                        <li><a href="kanjiy/13859">墩</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts16">
                                   <h3 class="ttl_while"><a href="kakusu16">１６画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6136">墻</a></li>
                                        <li><a href="kanjiy/13870">墼</a></li>
                                        <li><a href="kanjiy/13871">墽</a></li>
                                        <li><a href="kanjiy/13872">墿</a></li>
                                        <li><a href="kanjiy/13873">壀</a></li>
                                        <li><a href="kanjiy/13874">壂</a></li>
                                        <li><a href="kanjiy/13875">壆</a></li>
                                        <li><a href="kanjiy/13876">壈</a></li>
                                        <li><a href="kanjiy/13877">壉</a></li>
                                        <li><a href="10335">壃</a></li>
                                        <li><a href="kanjiy/19085">㙰</a></li>
                                        <li><a href="kanjiy/19086">㙱</a></li>
                                        <li><a href="kanjiy/19087">㙲</a></li>
                                        <li><a href="kanjiy/19088">㙳</a></li>
                                        <li><a href="kanjiy/19089">㙴</a></li>
                                        <li><a href="kanjiy/19090">㙵</a></li>
                                        <li><a href="kanjiy/19091">㙶</a></li>
                                        <li><a href="kanjiy/19094">㙹</a></li>
                                        <li><a href="kanjiy/23935">壒</a></li>
                                        <li><a href="kanjiy/24987">墶</a></li>
                                        <li><a href="kanjiy/24989">壋</a></li>
                                        <li><a href="kanjiy/26216">龳</a></li>
                                        <li><a class="color1" href="1032">壊</a>
                                        </li>
                                        <li><a class="color1" href="1263">壁</a>
                                        </li>
                                        <li><a class="color1" href="1414">墾</a>
                                        </li>
                                        <li><a class="color1" href="1499">壇</a>
                                        </li>
                                        <li><a class="color1" href="1758">壌</a>
                                        </li>
                                        <li><a href="kanjiy/27699">𡑮</a></li>
                                        <li><a href="kanjiy/27726">𡕀</a></li>
                                        <li><a href="kanjiy/27801">𡑭</a></li>
                                        <li><a href="3353">壅</a></li>
                                        <li><a href="5882">墺</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts17">
                                   <h3 class="ttl_while"><a href="kakusu17">１７画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6153">壓</a></li>
                                        <li><a href="6154">壗</a></li>
                                        <li><a href="kanjiy/13878">壍</a></li>
                                        <li><a href="kanjiy/13880">壔</a></li>
                                        <li><a href="kanjiy/13881">壖</a></li>
                                        <li><a href="10244">壐</a></li>
                                        <li><a href="kanjiy/12343">壎</a></li>
                                        <li><a href="kanjiy/19092">㙷</a></li>
                                        <li><a href="kanjiy/19093">㙸</a></li>
                                        <li><a href="kanjiy/19095">㙺</a></li>
                                        <li><a class="color2" href="2421">壕</a>
                                        </li>
                                        <li><a href="3354">壑</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts18">
                                   <h3 class="ttl_while"><a href="kakusu18">１８画</a></h3>
                                   <ul class="search_parts">
                                        <li><a class="color2" href="6155">壘</a>
                                        </li>
                                        <li><a href="kanjiy/13879">壏</a></li>
                                        <li><a href="kanjiy/19096">㙻</a></li>
                                        <li><a href="kanjiy/19097">㙼</a></li>
                                        <li><a href="kanjiy/26677">㙽</a></li>
                                        <li><a href="3355">壙</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts19">
                                   <h3 class="ttl_while"><a href="kakusu19">１９画</a></h3>
                                   <ul class="search_parts">
                                        <li><a class="color2" href="6151">壞</a>
                                        </li>
                                        <li><a href="kanjiy/13882">壚</a></li>
                                        <li><a href="kanjiy/13883">壛</a></li>
                                        <li><a href="kanjiy/13884">壢</a></li>
                                        <li><a href="kanjiy/19098">㙾</a></li>
                                        <li><a href="kanjiy/23936">壝</a></li>
                                        <li><a href="kanjiy/23937">壠</a></li>
                                        <li><a href="kanjiy/23938">壡</a></li>
                                        <li><a href="kanjiy/26678">㙿</a></li>
                                        <li><a href="3356">壜</a></li>
                                        <li><a href="3357">壟</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts20">
                                   <h3 class="ttl_while"><a href="kakusu20">２０画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="6135">壥</a></li>
                                        <li><a href="kanjiy/13885">壣</a></li>
                                        <li><a href="kanjiy/13886">壦</a></li>
                                        <li><a href="kanjiy/19099">㚀</a></li>
                                        <li><a href="5766">壤</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts22">
                                   <h3 class="ttl_while"><a href="kakusu22">２２画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/27728">𡔈</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts23">
                                   <h3 class="ttl_while"><a href="kakusu23">２３画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13887">壧</a></li>
                                        <li><a href="kanjiy/13888">壨</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts24">
                                   <h3 class="ttl_while"><a href="kakusu24">２４画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/13889">壩</a></li>
                                        <li><a href="kanjiy/19100">㚁</a></li>
                                   </ul>
                              </div>
                              <div class="parts_box" id="parts25">
                                   <h3 class="ttl_while"><a href="kakusu25">２５画</a></h3>
                                   <ul class="search_parts">
                                        <li><a href="kanjiy/19101">㚂</a></li>
                                        <li><a href="kanjiy/25008">壪</a></li>
                                   </ul>
                              </div>
                         </div><!--bushu_wrap-->
                         <a class="top_btn" href="bushu">部首検索TOPに戻る</a>
                   
                    </div><!--parts_data-->
               </div><!--content-->
               <aside>
                    <div id="sidebar" data-nosnippet>

                    
                         <div class="side_bnr link_pc">
                              <a href="#"><img
                                        src="../images/2023_side_bnr.jpg" alt="今年の漢字"></a>
                         </div>
                         <div class="side_bnr link_sp">
                              <a href="#"><img
                                        src="../images/2023_sp_bnr.jpg" alt="今年の漢字"></a>
                         </div>
                         <div class="side_ranking">
                              <script>
                                   $(function () {
                                        var sel_index = localStorage.getItem("sel_Elem2");
                                        if (sel_index == null) { sel_index = 0; }
                                        $('.ChangeElem_Btn2').eq(sel_index).addClass('is-active');
                                        $('.ChangeElem_Panel2').eq(sel_index).show();
                                        $('.ChangeElem_Btn2').each(function () {
                                             $(this).on('click', function () {
                                                  var parent = $(this).parents(".side_box");
                                                  var index = $(parent).find('.ChangeElem_Btn2').index(this);
                                                  $(parent).find('.ChangeElem_Btn2').removeClass('is-active');
                                                  $(this).addClass('is-active');
                                                  $(parent).find('.ChangeElem_Panel2').hide();
                                                  $(parent).find('.ChangeElem_Panel2').eq(index).show();
                                                  localStorage.setItem('sel_Elem2', index);
                                             });
                                        });
                                   });
                              </script>

                              <div class="side_box">
                                   <p class="ttl_normal_s">漢字検索ランキング<span class="rank_update">11/17更新</span></p>
                                   <ul class="ChangeElem_Btn_Content2 rank_menu">
                                        <li class="ChangeElem_Btn2">デイリー</li>
                                        <li class="ChangeElem_Btn2">週間</li>
                                        <li class="ChangeElem_Btn2">月間</li>
                                   </ul>
                                   <div class="ChangeElem_Panel2">
                                        <ul class="side_rank sr_01">
                                             <li><a href="kanji/059"
                                                       title="漢字「中」のページ"><span class="rank">1</span><span
                                                            class="jp">中</span></a></li>
                                             <li><a href="kanji/190"
                                                       title="漢字「長」のページ"><span class="rank">6</span><span
                                                            class="jp">長</span></a></li>
                                             <li><a href="kanji/136"
                                                       title="漢字「国」のページ"><span class="rank">2</span><span
                                                            class="jp">国</span></a></li>
                                             <li><a href="kanji/252"
                                                       title="漢字「駅」のページ"><span class="rank">7</span><span
                                                            class="jp">駅</span></a></li>
                                             <li><a href="kanji/071"
                                                       title="漢字「本」のページ"><span class="rank">3</span><span
                                                            class="jp">本</span></a></li>
                                             <li><a href="671"
                                                       title="漢字「寄」のページ"><span class="rank">8</span><span
                                                            class="jp">寄</span></a></li>
                                             <li><a href="kanji/086"
                                                       title="漢字「家」のページ"><span class="rank">4</span><span
                                                            class="jp">家</span></a></li>
                                             <li><a href="kanji/114"
                                                       title="漢字「兄」のページ"><span class="rank">9</span><span
                                                            class="jp">兄</span></a></li>
                                             <li><a href="775"
                                                       title="漢字「提」のページ"><span class="rank">5</span><span
                                                            class="jp">提</span></a></li>
                                             <li><a href="kanjiy/12934"
                                                       title="漢字「殺」のページ"><span class="rank">10</span><span
                                                            class="jp">殺</span></a></li>
                                        </ul>
                                   </div><!--ChangeElem_Panel2-->
                                   <div class="ChangeElem_Panel2">
                                        <ul class="side_rank">
                                             <li><a href="kanji/059"
                                                       title="漢字「中」のページ"><span class="rank">1</span><span
                                                            class="jp">中</span></a></li>
                                             <li><a href="kanji/163"
                                                       title="漢字「新」のページ"><span class="rank">6</span><span
                                                            class="jp">新</span></a></li>
                                             <li><a href="kanji/423"
                                                       title="漢字「有」のページ"><span class="rank">2</span><span
                                                            class="jp">有</span></a></li>
                                             <li><a href="602"
                                                       title="漢字「無」のページ"><span class="rank">7</span><span
                                                            class="jp">無</span></a></li>
                                             <li><a href="kanji/071"
                                                       title="漢字「本」のページ"><span class="rank">3</span><span
                                                            class="jp">本</span></a></li>
                                             <li><a href="911"
                                                       title="漢字「将」のページ"><span class="rank">8</span><span
                                                            class="jp">将</span></a></li>
                                             <li><a href="kanji/086"
                                                       title="漢字「家」のページ"><span class="rank">4</span><span
                                                            class="jp">家</span></a></li>
                                             <li><a href="kanji/190"
                                                       title="漢字「長」のページ"><span class="rank">9</span><span
                                                            class="jp">長</span></a></li>
                                             <li><a href="kanji/136"
                                                       title="漢字「国」のページ"><span class="rank">5</span><span
                                                            class="jp">国</span></a></li>
                                             <li><a href="kanji/094"
                                                       title="漢字「海」のページ"><span class="rank">10</span><span
                                                            class="jp">海</span></a></li>
                                        </ul>
                                   </div><!--ChangeElem_Panel2-->
                                   <div class="ChangeElem_Panel2">
                                        <ul class="side_rank">
                                             <li><a href="kanji/059"
                                                       title="漢字「中」のページ"><span class="rank">1</span><span
                                                            class="jp">中</span></a></li>
                                             <li><a href="kanji/086"
                                                       title="漢字「家」のページ"><span class="rank">6</span><span
                                                            class="jp">家</span></a></li>
                                             <li><a href="991"
                                                       title="漢字「優」のページ"><span class="rank">2</span><span
                                                            class="jp">優</span></a></li>
                                             <li><a href="kanji/398"
                                                       title="漢字「美」のページ"><span class="rank">7</span><span
                                                            class="jp">美</span></a></li>
                                             <li><a href="602"
                                                       title="漢字「無」のページ"><span class="rank">3</span><span
                                                            class="jp">無</span></a></li>
                                             <li><a href="kanji/423"
                                                       title="漢字「有」のページ"><span class="rank">8</span><span
                                                            class="jp">有</span></a></li>
                                             <li><a href="kanji/439"
                                                       title="漢字「和」のページ"><span class="rank">4</span><span
                                                            class="jp">和</span></a></li>
                                             <li><a href="kanji/071"
                                                       title="漢字「本」のページ"><span class="rank">9</span><span
                                                            class="jp">本</span></a></li>
                                             <li><a href="kanji/440"
                                                       title="漢字「愛」のページ"><span class="rank">5</span><span
                                                            class="jp">愛</span></a></li>
                                             <li><a href="kanji/027"
                                                       title="漢字「子」のページ"><span class="rank">10</span><span
                                                            class="jp">子</span></a></li>
                                        </ul>
                                   </div><!--ChangeElem_Panel2-->
                              </div>
                         </div>
                         <script>
                              $(function () {
                                   $('.togglemenu').click(function () {
                                        $(this).toggleClass("active").next().slideToggle(300);
                                   });
                              });
                         </script>
                         <div class="side_box">
                              <p class="ttl_main_s togglemenu">検索メニュー</p>
                              <div class="togglebox">
                                   <ul class="other_site">
                                        <li><a href="yomi">読み検索（音訓検索）</a></li>
                                        <li><a href="kakusu">画数検索</a></li>
                                        <li><a href="bushu">部首検索</a></li>
                                        <li><a href="kousei/">構成検索</a></li>
                                        <li><a href="kyu">漢検の級（習う学年）から検索</a></li>
                                        <li><a href="searchdetail">詳細検索</a></li>
                                   </ul>
                              </div><!--togglebox-->
                         </div><!--side_box-->
                         <div class="side_box">
                              <p class="ttl_main_s togglemenu">練習帳</p>
                              <div class="togglebox">
                                   <ul class="other_site">
                                        <li><a href="">漢字練習帳</a></li>
                                        <li><a href="#kr1">カスタム練習帳</a>
                                        </li>
                                        <li><a
                                                  href="#kr2">漢検級別（学年別）練習帳</a>
                                        </li>
                                   </ul>
                              </div><!--togglebox-->
                         </div><!--side_box-->
                         <div class="side_box">
                              <p class="ttl_main_s togglemenu">漢字の種別</p>
                              <div class="togglebox">
                                   <ul class="other_site">
                                        <li><a href="joyo">常用漢字</a></li>
                                        <li><a href="kyoiku">教育漢字</a></li>
                                        <li><a href="jimmei">人名用漢字</a></li>
                                        <li><a href="namae">名前に使える漢字</a></li>
                                        <li><a href="kokuji">国字</a></li>
                                   </ul>
                              </div><!--togglebox-->
                         </div><!--side_box-->
                         <div class="side_box">
                              <p class="ttl_main_s togglemenu">漢字の分類・漢字表記</p>
                              <div class="togglebox">
                                   <ul class="other_site">
                                        <li><a href="sakuin1">漢字の分類・漢字表記索引</a></li>
                                   </ul>
                              </div><!--togglebox-->
                         </div><!--side_box-->
                         <!--side_box-->
                    </div><!--sidebar-->
               </aside>
          </div>   <script>
    jQuery(document).ready(function($) { 
  
    $('.search_parts li a').mouseenter(function() { 
        var star = $(this).text(); 
        star2 ="";
        $('.search_parts li a').attr('href','<?php echo home_url(); ?>'+'/detail-three/'+'/?bold='+star+'&normal='+star2);  
        console.log('<?php echo home_url(); ?>'+'/detail-three/'+'/?bold='+star+'&normal='+star2); 
        console.log("bold "+ star); 
    });
        });
</script>
            <footer>
               <div class="footer_wrap" data-nosnippet>
                    <div class="center">
                         <div class="footer_bottom">
                              <ul class="footer_menu">
                                   <li><a href="info">報告・お問い合わせ</a></li>
                                   <li><a href="privacy">プライバシーポリシー</a></li>
                                   <li><a href="">参考文献</a></li>
                                   <li><a href="">運営サイト一覧</a></li>
                                   <li><a href="">運営会社</a></li>
                              </ul>
                              <div class="language_footer">
                                   <div class="lan_inner">
                                        <select name="select" onChange="location.href=value;" tabindex="0">
                                             <option value="" selected>Language</option>
                                             <option value="radical32">English</option>
                                             <option value="bushu03012">Japanese</option>
                                        </select>
                                   </div>
                              </div>
                         </div>
                    </div>
               </div>
               <p class="copyright">&copy; 2012-2023 漢字辞典オンライン</p>
          </footer>
     </div><!--all-->
</body>

<!-- Mirrored from bushu03012 by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 17 Nov 2023 00:39:46 GMT -->

</html>